import controller.CampeonatoController;

public class Main {

    public static void main(String[] args) {

        CampeonatoController nuevoCampeonato = new CampeonatoController();
        nuevoCampeonato.iniciarCampeonato();

    }
}
